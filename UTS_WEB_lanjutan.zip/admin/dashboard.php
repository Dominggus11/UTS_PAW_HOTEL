<?php
include './sidebar.php'
?>

<div class="container p-3 m-4 h-100" style="background-color: #FFFFFF; border-top: 5px solid #1d1b31; box-shadow:
0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
    <h4>OUR TEAM</h4>
    <hr>
    <div class="d-flex">
        <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="https://asistenpw21.netlify.app/static/media/mili.002ce375.png" width="30px" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Alessandro Moreno</h5>
                <p class="cardtext">
                    Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
        <div class="card mx-4" style="width: 18rem;">
            <img class="card-img-top" src="https://asistenpw21.netlify.app/static/media/mili.002ce375.png" width="30px" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Eduard Sebastian</h5>
                <p class="cardtext">
                    Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
        <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="https://asistenpw21.netlify.app/static/media/mili.002ce375.png" width="30px" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Roy Dominggus Andornov</h5>
                <p class="cardtext">
                    Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>
</div>
</aside>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>

</html>