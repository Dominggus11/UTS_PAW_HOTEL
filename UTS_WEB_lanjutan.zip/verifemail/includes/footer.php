<!--- Start Footer -->
<footer>
    <div class="container-fluid" style="background-color:#242726">
        <div class="row text-center py-5">
            <div class="col-md-6">
                <h3 class="text-center" style="color:white">CONTACT INFO</h3>
                <p style="color:white">Jl. Babarsari No.43, Janti, Caturtunggal,<br>
                Kec. Depok, Kabupaten Sleman, Daerah Istimewa Yogyakarta 55281<br>
                <br><strong style="color:white">(0274) 487711</strong></p>
            </div>
            <div class="col-md-6">
                <h3 class="text-center" style="color:white">CONNECT WITH US</h3>
                <span><img src="img/instagram.png" width="30px" height="30px"/></span>
                <span><img src="img/youtube.png" width="30px" height="25px"/></span>
                <span><img src="img/facebook.png" width="42px" height="30px"/></span>
                <span><img src="img/twitter.png" width="30px" height="30px"/></span>
                <span><img src="img/whatsapp.png" width="30px" height="30px"/></span>
            </div>
            <p style="color:white">Copyright © 2021 Yasogami Hotel, All Right Reserved.</p>
        </div><!--- End of Row -->
    </div><!--- End of Container -->
</footer>
<!--- End of Footer -->