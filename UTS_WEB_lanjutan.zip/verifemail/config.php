<?php
    $con = mysqli_connect('localhost' ,'root','','uts_web') or die ("ERROR CONNECTION");
?>